namespace Ui {
    void MainRender();
    void CheatRender();
}

namespace UiGlobals {
    inline bool ModFly;
}