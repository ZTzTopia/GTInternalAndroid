#pragma once

namespace GuiUtils {
    bool IsAnyScrollBarActive();
    bool MouseOnImguiTitleBarWindow();
    void ScrollWhenDraggingOnVoid();
}
