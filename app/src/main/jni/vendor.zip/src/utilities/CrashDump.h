#pragma once

class CrashDump {
public:
    static void Init();

private:
    static void handler();
};