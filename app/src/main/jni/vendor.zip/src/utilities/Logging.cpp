#include "Logging.h"

void Logging::Log() {
    // Todo: log to file
}