#pragma once

namespace Logging {
    void Log();
}
